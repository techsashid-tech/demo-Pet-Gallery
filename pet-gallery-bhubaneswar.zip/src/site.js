/* ==========================================================================
   PET GALLERY BHUBANESWAR / KATAKA - CORE JAVASCRIPT ENGINE
   ========================================================================== */

const PET_GALLERY_MAP_URL = "https://www.google.com/maps/place/Pet+Gallery/@20.4377374,85.9024607,13z/data=!4m16!1m9!3m8!1s0x3a190dbe5fed882b:0x2307564701fab489!2sPet+Gallery!8m2!3d20.4530099!4d85.9166043!9m1!1b1!16s%2Fg%2F11n0p623rg!3m5!1s0x3a190dbe5fed882b:0x2307564701fab489!8m2!3d20.4530099!4d85.9166043!16s%2Fg%2F11n0p623rg?entry=ttu&g_ep=EgoyMDI2MDkwOS4wIKXMDSoASAFQAw%3D%3D";
const PET_GALLERY_MAP_GALLERY_URL = "https://www.google.com/maps/place/Pet+Gallery/@20.4530099,85.9166043,3a,75y,90t/data=!3m8!1e5!3m6!1sCIHM0ogKEICAgICNw5uV9gE!2e10!3e10!6shttps:%2F%2Flh3.googleusercontent.com%2Fgps-cs-s%2FAHRPTWluHZ7N-6mT1G5RGudFLYMoKuqFrK2ZJC67aawtHzamXq6dj9O74bvSPTd6UWXmQ7vaubZN5LvWWcdftF7lJcbC6a69KT9-FQEhkIsX-J6xrUIC2zTCVJ7P72wkwQsYNWWsZI3ExA%3Dw224-h403-k-no!7i480!8i864!4m19!1m9!3m8!1s0x3a190dbe5fed882b:0x2307564701fab489!2sPet+Gallery!8m2!3d20.4530099!4d85.9166043!9m1!1b1!16s%2Fg%2F11n0p623rg!3m8!1s0x3a190dbe5fed882b:0x2307564701fab489!8m2!3d20.4530099!4d85.9166043!10e5!14m1!1BCgIgAQ!16s%2Fg%2F11n0p623rg?entry=ttu&g_ep=EgoyMDI2MDkwOS4wIKXMDSoASAFQAw%3D%3D";
const PET_GALLERY_REVIEWS_URL = "https://www.google.com/maps/place/Pet+Gallery/@20.4377374,85.9024607,13z/data=!4m18!1m9!3m8!1s0x3a190dbe5fed882b:0x2307564701fab489!2sPet+Gallery!8m2!3d20.4530099!4d85.9166043!9m1!1b1!16s%2Fg%2F11n0p623rg!3m7!1s0x3a190dbe5fed882b:0x2307564701fab489!8m2!3d20.4530099!4d85.9166043!9m1!1b1!16s%2Fg%2F11n0p623rg?entry=ttu&g_ep=EgoyMDI2MDkwOS4wIKXMDSoASAFQAw%3D%3D";
const PET_GALLERY_PHONE = "09438224113";
const PET_GALLERY_WHATSAPP_NUM = "919438224113";
const PET_GALLERY_EMAIL = "petgallery.kataka@gmail.com";

// Bind all Google Map Gallery direct section buttons
document.querySelectorAll('.google-map-gallery-trigger').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    window.open(PET_GALLERY_MAP_GALLERY_URL, '_blank', 'noopener,noreferrer');
  });
});

// Bind all Google Maps place / location buttons
document.querySelectorAll('.google-maps-trigger').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    window.open(PET_GALLERY_MAP_URL, '_blank', 'noopener,noreferrer');
  });
});

// Bind all Read Reviews buttons
document.querySelectorAll('.google-reviews-trigger').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    window.open(PET_GALLERY_REVIEWS_URL, '_blank', 'noopener,noreferrer');
  });
});

// Inquiry form submission logic
window.handleInquirySubmit = function(e) {
  e.preventDefault();
  const name = document.getElementById('clientFullName')?.value.trim() || '';
  const phone = document.getElementById('clientPhone')?.value.trim() || '';
  const interest = document.getElementById('clientInterest')?.value || 'Pet Discovery';
  const batch = document.getElementById('clientBatch')?.value || 'Morning';
  const successMsg = document.getElementById('formSuccessMessage');
  if (successMsg) {
    successMsg.innerHTML = `<i class="fa-solid fa-circle-check" style="margin-right: 6px;"></i> Thank you, <strong>${name}</strong>! Your inquiry for <em>${interest}</em> has been received. Our team will contact you at <strong>${phone}</strong> during <strong>${batch}</strong>.`;
    successMsg.style.display = 'block';
    triggerSignaturePawStreak();
  }
};

// Direct WhatsApp sending from inquiry form
window.sendInquiryViaWhatsApp = function() {
  const name = document.getElementById('clientFullName')?.value.trim() || 'Pet Lover';
  const phone = document.getElementById('clientPhone')?.value.trim() || '';
  const interest = document.getElementById('clientInterest')?.value || 'Pet Care & Accessories';
  const batch = document.getElementById('clientBatch')?.value || 'Anytime';
  const queries = document.getElementById('clientQueries')?.value.trim() || 'Inquiring about pets and accessories at Kataka store';
  let text = `Hello Pet Gallery Kataka!%0A%0A*Name:* ${encodeURIComponent(name)}%0A*Interest:* ${encodeURIComponent(interest)}%0A*Preferred Contact Time:* ${encodeURIComponent(batch)}`;
  if (phone) text += `%0A*Phone:* ${encodeURIComponent(phone)}`;
  if (queries) text += `%0A*Query:* ${encodeURIComponent(queries)}`;
  window.open(`https://wa.me/${PET_GALLERY_WHATSAPP_NUM}?text=${text}`, '_blank', 'noopener,noreferrer');
};

// Preloader Logic
window.addEventListener('DOMContentLoaded', () => {
  const counter = document.getElementById('loadingCounter');
  const preloader = document.getElementById('preloader');
  if (!counter || !preloader) return;
  let count = 1;
  const interval = setInterval(() => {
    count += Math.floor(Math.random() * 5) + 3;
    if (count >= 100) {
      count = 100;
      clearInterval(interval);
      counter.textContent = "100";
      setTimeout(() => {
        preloader.classList.add('loaded');
        triggerSignaturePawStreak();
      }, 300);
    } else {
      counter.textContent = count < 10 ? '0' + count : count;
    }
  }, 20);
});

// Signature Paw Streak
function triggerSignaturePawStreak() {
  const streak = document.getElementById('signaturePawStreak');
  if (!streak) return;
  streak.classList.add('active');
  setTimeout(() => {
    streak.classList.remove('active');
  }, 1600);
}
window.triggerSignaturePawStreak = triggerSignaturePawStreak;

// Theme Toggle
const htmlEl = document.documentElement;
const themeBtn = document.getElementById('themeToggleBtn');
const themeIcon = document.getElementById('themeIcon');
const savedTheme = localStorage.getItem('pet_gallery_theme') || 'dark';
setTheme(savedTheme);

if (themeBtn) {
  themeBtn.addEventListener('click', () => {
    const currentTheme = htmlEl.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    triggerSignaturePawStreak();
  });
}

function setTheme(theme) {
  htmlEl.setAttribute('data-theme', theme);
  localStorage.setItem('pet_gallery_theme', theme);
  if (themeIcon) {
    if (theme === 'dark') {
      themeIcon.className = 'fa-solid fa-sun';
    } else {
      themeIcon.className = 'fa-solid fa-moon';
    }
  }
}

// Navbar Scroll & Scroll Progress
const mainNav = document.getElementById('mainNav');
const scrollProgress = document.getElementById('scrollProgress');
const verticalThumb = document.getElementById('verticalScrollThumb');

window.addEventListener('scroll', () => {
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const scrollPercent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
  if (scrollProgress) scrollProgress.style.width = scrollPercent + '%';
  if (verticalThumb) verticalThumb.style.height = scrollPercent + '%';
  if (mainNav) {
    if (scrollTop > 40) {
      mainNav.classList.add('scrolled');
    } else {
      mainNav.classList.remove('scrolled');
    }
  }

  // Active nav link
  const sections = document.querySelectorAll('section[id]');
  sections.forEach(sec => {
    const top = sec.offsetTop - 140;
    const height = sec.offsetHeight;
    const id = sec.getAttribute('id');
    if (scrollTop >= top && scrollTop < top + height) {
      document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + id) {
          link.classList.add('active');
        }
      });
    }
  });
}, { passive: true });

// Mobile Menu Overlay
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileOverlay = document.getElementById('mobileMenuOverlay');
if (mobileMenuBtn && mobileOverlay) {
  mobileMenuBtn.addEventListener('click', () => {
    mobileOverlay.classList.toggle('active');
  });
  document.querySelectorAll('.mobile-nav-link').forEach(link => {
    link.addEventListener('click', () => {
      mobileOverlay.classList.remove('active');
    });
  });
}

// Hero Card 3D Tilt
const heroCard = document.getElementById('heroTiltCard');
if (heroCard && window.innerWidth > 992) {
  heroCard.addEventListener('mousemove', (e) => {
    const rect = heroCard.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    const rotateX = -(y / rect.height) * 16;
    const rotateY = (x / rect.width) * 16;
    heroCard.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
  });
  heroCard.addEventListener('mouseleave', () => {
    heroCard.style.transform = 'rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
  });
}

// Pet Discovery Filter Tabs
const filterTabs = document.querySelectorAll('.filter-tab');
const petCards = document.querySelectorAll('.pet-card');
filterTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    filterTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const filter = tab.getAttribute('data-filter');
    petCards.forEach(card => {
      if (filter === 'all' || card.getAttribute('data-category') === filter) {
        card.style.display = 'block';
        card.style.animation = 'heroWordFade 0.4s ease forwards';
      } else {
        card.style.display = 'none';
      }
    });
  });
});

// NEW: In-Store Product Showcase Filter Tabs
const productFilterBtns = document.querySelectorAll('.product-filter-btn');
const productCards = document.querySelectorAll('.product-card');
productFilterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    productFilterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cat = btn.getAttribute('data-prod-filter');
    productCards.forEach(card => {
      if (cat === 'all' || card.getAttribute('data-prod-cat') === cat) {
        card.style.display = 'flex';
        card.style.animation = 'heroWordFade 0.4s ease forwards';
      } else {
        card.style.display = 'none';
      }
    });
  });
});

// 3D Glass Carousel Rotation
const carousel = document.getElementById('carousel3d');
const prevBtn = document.getElementById('prevGalleryBtn');
const nextBtn = document.getElementById('nextGalleryBtn');
const stage = document.getElementById('galleryStage');
let currentAngle = 0;
let autoRotate = true;

function rotateGallery(direction) {
  if (!carousel) return;
  currentAngle += direction * 60;
  carousel.style.transform = `rotateY(${currentAngle}deg)`;
}

if (prevBtn && nextBtn && carousel) {
  prevBtn.addEventListener('click', () => {
    rotateGallery(1);
    autoRotate = false;
  });
  nextBtn.addEventListener('click', () => {
    rotateGallery(-1);
    autoRotate = false;
  });
  setInterval(() => {
    if (autoRotate) {
      currentAngle -= 60;
      carousel.style.transform = `rotateY(${currentAngle}deg)`;
    }
  }, 4200);
  if (stage) {
    stage.addEventListener('mouseenter', () => { autoRotate = false; });
    stage.addEventListener('mouseleave', () => { autoRotate = true; });
  }
}

// Modal Inspection for Gallery & Product Items
const modal = document.getElementById('imageModal');
const modalImg = document.getElementById('modalImg');
const modalClose = document.getElementById('modalCloseBtn');

document.querySelectorAll('.carousel-item, .pet-card-media img, .moment-panel img, .product-card-img').forEach(imgEl => {
  imgEl.addEventListener('click', (e) => {
    const src = e.target.tagName === 'IMG' ? e.target.src : e.target.querySelector('img')?.src;
    if (src && modal && modalImg) {
      modalImg.src = src;
      modal.classList.add('active');
    }
  });
});

if (modalClose) {
  modalClose.addEventListener('click', () => modal?.classList.remove('active'));
}
if (modal) {
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('active');
  });
}

// Client-Side Photo Community
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('petPhotoInput');
const previewContainer = document.getElementById('previewContainer');
const previewImage = document.getElementById('previewImage');
const addToBoardBtn = document.getElementById('addToBoardBtn');
const communityFeed = document.getElementById('communityFeedGrid');

if (dropZone && fileInput) {
  ['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      dropZone.classList.add('dragover');
    });
  });
  ['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });
  dropZone.addEventListener('drop', (e) => {
    const files = e.dataTransfer?.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  });
  fileInput.addEventListener('change', (e) => {
    const target = e.target;
    if (target.files && target.files[0]) {
      handleFile(target.files[0]);
    }
  });
}

function handleFile(file) {
  if (!file.type.startsWith('image/')) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    if (previewImage && previewContainer) {
      previewImage.src = e.target.result;
      previewContainer.style.display = 'block';
      previewContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  };
  reader.readAsDataURL(file);
}

if (addToBoardBtn) {
  addToBoardBtn.addEventListener('click', () => {
    if (!previewImage?.src || !communityFeed) return;
    const newCard = document.createElement('div');
    newCard.className = 'community-photo-card light-pass';
    newCard.innerHTML = `<img src="${previewImage.src}" alt="Community Pet Submission">`;
    communityFeed.prepend(newCard);
    if (previewContainer) previewContainer.style.display = 'none';
    triggerSignaturePawStreak();
  });
}
